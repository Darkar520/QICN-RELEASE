from pathlib import Path
import hashlib,json,re,collections
P=Path(__file__).resolve().parent;W=P/'workspace';B=P/'baseline';I=W/'rigid-identity-framework';BI=B/'rigid-identity-framework'
manifest=json.loads((P/'logs/baseline-hashes.json').read_text(encoding='utf8'));protected={k:v for k,v in manifest.items() if k.startswith(('release/','corpus/','artifacts/','rigid-identity-framework/canonical_core_legacy/','rigid-identity-framework/docs/ai-platform-outputs/repair-plans/RUTA3_NO_VACUIDAD_ESTABILIDAD_2026-11-12/')) or k.endswith('.lean')}
bad=[k for k,h in protected.items() if hashlib.sha256((W/k).read_bytes()).hexdigest()!=h]
assert not bad,bad
files=[p for p in (BI/'basecore').rglob('*.tex')]+[p for f in BI.glob('paper*') if f.is_dir() for p in f.rglob('*.tex')]
strip=lambda s:re.sub(r'(?<!\\)%[^\n]*','',s)
envs=r'theorem|lemma|proposition|corollary|definition|proof|assumption|axiom|conjecture|remark|caveat|example|nontheorem|hypothesis|claim|nonclaim|nonclaimbox'
pattern=re.compile(r'\\begin\{('+envs+r')\}(?:\[[^\]\n]*\])?([\s\S]*?)\\end\{\1\}')
def math_fragments(s):
 # TeX escaping depends on parity, not a one-character lookbehind: \\\\$ opens
 # math after a line break; \\$ is a literal dollar. Keep both cases distinct.
 dollars=[];opened=None;i=0
 while i<len(s):
  if s[i]=='$':
   k=i-1
   while k>=0 and s[k]=='\\':k-=1
   if (i-1-k)%2==0:
    if opened is None:opened=i
    else:dollars.append(s[opened:i+1]);opened=None
  i+=1
 assert opened is None,'unpaired math delimiter'
 displays=re.findall(r'\\\[[\s\S]*?\\\]|\\\([\s\S]*?\\\)',s)
 equations=[m[0] for m in re.finditer(r'\\begin\{(equation\*?|align\*?|gather\*?)\}[\s\S]*?\\end\{\1\}',s)]
 return dollars+displays+equations
units=[]
for f in sorted(files):
 rel=f.relative_to(BI);a=f.read_text(encoding='utf8');b=(I/rel).read_text(encoding='utf8');sa=strip(a);sb=strip(b)
 labels=lambda s:re.findall(r'\\label\{([^}]+)\}',s)
 assert labels(sa)==labels(sb),('labels',str(rel))
 # The only changed body is a remark's prose reference to an internal audit
 # version, enumerated before verification; no theorem/definition/proof changes.
 editorial_ref=lambda t:t.replace('The v31 conditional closure theorem concerns a different case:','The conditional theorem on defined witness endpoints concerns a different case:')
 ea=[(m[1],editorial_ref(m[2].strip())) for m in pattern.finditer(sa)];eb=[(m[1],m[2].strip()) for m in pattern.finditer(sb)]
 assert ea==eb,('formal body changed',str(rel),len(ea),len(eb))
 ta=re.findall(r'\\(begin|end)\{('+envs+r')\}',sa);tb=re.findall(r'\\(begin|end)\{('+envs+r')\}',sb)
 assert ta==tb,('topology',str(rel))
 ma=math_fragments(sa);mb=math_fragments(sb)
 assert ma==mb,('math',str(rel))
 units.append({'file':rel.as_posix(),'changed':a!=b,'labels':len(labels(sa)),'formal_bodies':len(ea),'math_fragments':len(ma),'bodies_sha256':hashlib.sha256(json.dumps(ea).encode()).hexdigest(),'formal_topology_equal':True,'all_math_fragments_equal':True})
result={'protected_count':len(protected),'frozen_root_files':sum(k.startswith(('release/','corpus/','artifacts/')) for k in protected),'lean_modules':sum(k.endswith('.lean') for k in protected),'protected_sha256':protected,'units':units,'formal_bodies':sum(x['formal_bodies'] for x in units),'math_fragments':sum(x['math_fragments'] for x in units),'all_equal':True,'external_support_certified':False}
(P/'logs/preservation.json').write_text(json.dumps(result,indent=2),encoding='utf8')
print(json.dumps({k:result[k] for k in ['protected_count','frozen_root_files','lean_modules','formal_bodies','math_fragments','all_equal']}))
