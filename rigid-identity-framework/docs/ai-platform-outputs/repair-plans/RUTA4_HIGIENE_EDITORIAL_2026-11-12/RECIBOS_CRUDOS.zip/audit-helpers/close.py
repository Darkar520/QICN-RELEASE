from pathlib import Path
import json, hashlib, subprocess, difflib, zipfile, shutil, sys, datetime, os, re

P=Path(__file__).resolve().parent
W=P/'workspace'; B=P/'baseline'; I=W/'rigid-identity-framework'
C=Path('C:/Users/irisp/OneDrive/Escritorio/qicn-framework-ordenado')
REL=Path('rigid-identity-framework/docs/ai-platform-outputs/repair-plans/RUTA4_HIGIENE_EDITORIAL_2026-11-12')
D=W/REL
BASE='5535a5c0b7669ce4e7e86705334b935ec3e19618'
papers=['paper3','paper4','paper6_predictions_falsation','paper9_phenomenal_bridge_organization','paper10_external_adjudication']
fixed=[f'rigid-identity-framework/{f}/{name}' for f in papers for name in ['main.tex','main.pdf']]+[
 'rigid-identity-framework/scripts/build-monolithic-volume.js',
 'rigid-identity-framework/monolithic/preamble/source-contract.json',
 'rigid-identity-framework/monolithic/QICN_MONOLITHIC.tex',
 'rigid-identity-framework/monolithic/QICN_MONOLITHIC.pdf',
 'rigid-identity-framework/monolithic/README.md',
 'rigid-identity-framework/registry/theorems.jsonl',
 'rigid-identity-framework/registry/macros.jsonl',
 'rigid-identity-framework/docs/reports/MONOLITHIC_BUILD_REPORT.md',
 'rigid-identity-framework/ROADMAP.md',
 'rigid-identity-framework/docs/ai-platform-outputs/IMPLEMENTATION_TRACE_LEDGER.md']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return p.read_text(encoding='utf-8-sig')
def js(p):return json.loads(read(p))
def dump(p,data):p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def command(name,args,cwd):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 result=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (P/'logs'/f'{name}.log').write_bytes(result.stdout)
 return {'name':name,'command':args,'cwd':str(cwd),'exit':result.returncode,'started_utc':start}
def whitelist():return sorted(fixed+[p.relative_to(W).as_posix() for p in D.iterdir() if p.is_file()])

if sys.argv[1]=='audit':
 records=[command('final-corpus-json',['node','scripts/validate-corpus.js','--json'],I)]
 assert all(r['exit']==0 for r in records),records
 dump(P/'logs/final-extra-commands.json',records)
 changes=js(D/'CAMBIOS_EDITORIALES.json')['changes']
 counts=[]; diffs=[]
 sections={'paper3':'03_paper3.tex','paper4':'04_paper4.tex','paper6_predictions_falsation':'06_paper6.tex','paper9_phenomenal_bridge_organization':'09_paper9.tex','paper10_external_adjudication':'10_paper10.tex'}
 actual_sections=list((I/'monolithic/build/sections').glob('*.tex'))
 for folder in papers:
  a=read(B/'rigid-identity-framework'/folder/'main.tex');b=read(I/folder/'main.tex')
  diffs+=list(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=folder+'/main.tex@'+BASE[:7],tofile=folder+'/main.tex@Route4'))
 for x in changes:
  a=read(B/'rigid-identity-framework'/x['file']);b=read(I/x['file'])
  if 'old' in x:
   old=x['old'];new=x['new'];row={'file':x['file'],'old':old,'new':new,'before_old':a.count(old),'after_old':b.count(old),'before_new':a.count(new) if new else None,'after_new':b.count(new) if new else None}
   assert row['before_old']>0 and row['after_old']==0,row
   if new:assert row['after_new']>0,row
   counts.append(row)
  else:
   for m in x['mapping']:
    marker=m['path']
    normalize=lambda s:re.sub(r'\\detokenize\{([^{}]*)\}',r'\1',s).replace(r'\allowbreak{}','')
    boundary=r'\subsection*{Appendix A:'
    before=normalize(a.split(boundary)[0]);after=normalize(b.split(boundary)[0]);appendix=normalize(b.split(boundary)[1])
    assert marker in before and marker not in after and marker in appendix,m
    counts.append({'file':x['file'],'schema':m['path'],'main_before':before.count(marker),'main_after':after.count(marker),'appendix_after':appendix.count(marker),'description':m['description']})
 (P/'logs/source-diff.patch').write_text(''.join(diffs),encoding='utf8')
 dump(P/'logs/phrase-counts.json',{'source_changes':counts,'monolithic_propagation':'Full 12-chapter byte equality is checked independently in LF and CRLF; source date is intentionally excluded by the assembler.','external_support_certified':False})
 # The only source-contract edit must be the hash for the changed date.
 old=js(B/'rigid-identity-framework/monolithic/preamble/source-contract.json');new=js(I/'monolithic/preamble/source-contract.json')
 def delta(a,b,path=''):
  if isinstance(a,dict) and isinstance(b,dict):
   assert a.keys()==b.keys()
   return sum([delta(a[k],b[k],path+'/'+k) for k in a],[])
  if isinstance(a,list) and isinstance(b,list):
   assert len(a)==len(b)
   return sum([delta(x,y,path+'/'+str(n)) for n,(x,y) in enumerate(zip(a,b))],[])
  return [] if a==b else [{'path':path,'before':a,'after':b}]
 contract=delta(old,new);assert len(contract)==1,contract
 # Builder executable code is unchanged; only the existing editorial string differs.
 aa=read(B/'rigid-identity-framework/scripts/build-monolithic-volume.js');bb=read(I/'scripts/build-monolithic-volume.js')
 def outside(s):
  start=s.index('const EDITORIAL_PREFACE = String.raw`');end=s.index('`;',start)+2
  return s[:start]+s[end:]
 assert outside(aa)==outside(bb),'builder code changed outside editorial string'
 dump(P/'logs/assembly-change.json',{'contract_diff':contract,'builder_change_confined_to_editorial_preface':True,'frozen_hashes_checked_in':'preservation.json'})
 print('Audit passed: corpus JSON, exact source edits, schema provenance, source contract, assembler scope.')

elif sys.argv[1]=='bundle':
 z=D/'RECIBOS_CRUDOS.zip'
 selected=[p for p in (P/'logs').rglob('*') if p.is_file() and p.suffix in ('.json','.log','.patch','.txt') and p.name not in ['monolithic-text.txt','delivery-manifest.json','desktop-transfer.json']]
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
  for f in sorted(selected):out.write(f,'logs/'+f.relative_to(P/'logs').as_posix())
  for f in [P/x for x in ['check-preservation.py','line-endings.cjs','layout.py','registry.cjs','reviewer-map.py','close.py','compile.py','verify_stage.py']]:out.write(f,'audit-helpers/'+f.name)
  for f in [I/'docs/reports/V35_ALL_LEGACY_VERIFICATION.json',I/'docs/reports/MONOLITHIC_BUILD_REPORT.md']:
   if f.exists():out.write(f,'reports/'+f.name)
  for f in sorted((I/'docs/reports').glob('*ADJUDICATION*.json')):out.write(f,'reports/'+f.name)
 preservation=js(P/'logs/preservation.json');reg=js(P/'logs/registry-preservation.json');layout=js(P/'logs/layout.json')
 receipt={'phase':'Route 4 editorial only','baseline_commit':BASE,'started':'2026-11-12','completed':'2026-11-13','external_support_certified':False,
  'preregistration_sha256':sha(D/'PRERREGISTRO.md'),
  'scope':{'standalone_tex_changed':5,'reader_guide_pdf_page':3,'reader_guide_pages':1,'reviewer_results':24,'monolith_pages':440},
  'conservation':{k:preservation[k] for k in ['protected_count','frozen_root_files','lean_modules','formal_bodies','math_fragments','all_equal']},
  'registry':{k:reg[k] for k in ['original_ids','final_ids','ids_preserved','new_or_removed_ids','macro_count','curation_preserved']},
  'registry_changed_rows':len(reg['changes']),'compilation':layout,
  'gates':js(P/'logs/initial-gates/commands.json')+js(P/'logs/final-extra-commands.json'),
  'desktop_checks':js(P/'logs/desktop-checks.json') if (P/'logs/desktop-checks.json').exists() else [],
  'source_chapter_comparator':js(P/'logs/line-endings.json'),
  'lean':'No rebuild in Route 4; all 32 Lean source hashes equal the Route 3 kernel-verified snapshot. Route 3 receipts unchanged.',
  'raw_verdicts':{'verify:v25':'INTERNAL_DIAGNOSTIC_PASS_SYNTHETIC_ONLY','verify:v26':'INTERNAL_DIAGNOSTIC_PASS_SYNTHETIC_ONLY','verify:v27':'BLOCKED_MULTIPLE_GATES','adjudicate:v28':'BLOCKED_MULTIPLE_GATES','verify:v30':'BLOCKED_MULTIPLE_GATES','verify:v31':'BLOCKED_FOUNDATION_FIRST_GATES'},
  'known_limits':['Additional optional legacy v24 checker fails on baseline and Route 4 because an untracked historical fixture is absent; active release 6/6 passes.','181 Underfull hbox warnings and 4 float-placement adjustments in monolith.','Lemma 8.41 AUX page counter precedes its printed heading by one page; guide uses actual PDF 315. Baseline PDF destination 313 advances by two added frontmatter pages to final PDF destination 315.','AI/editorial and software checks are not independent human mathematical review or empirical evidence.'],
  'archive':{'file':'RECIBOS_CRUDOS.zip','sha256':sha(z),'bytes':z.stat().st_size},
  'delivery_sha256':{f:sha(W/f) for f in fixed if (W/f).exists() and not f.endswith(('ROADMAP.md','IMPLEMENTATION_TRACE_LEDGER.md'))},
  'publication':'Authorized by user Option B; final Git refs and clean-tree checks are recorded after delivery.'}
 dump(D/'VERIFICACION.json',receipt)
 dump(P/'logs/delivery-manifest.json',{f:sha(W/f) for f in whitelist()})
 print(json.dumps({'archive_bytes':z.stat().st_size,'files_for_delivery':len(whitelist()),'registry_rows_changed':len(reg['changes']),'receipt':str(D/'VERIFICACION.json')}))

elif sys.argv[1]=='transfer':
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=C,text=True).strip()==BASE,'HEAD changed; stop'
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=C,text=True).strip(),'Desktop is not clean; stop'
 manifest=js(P/'logs/baseline-hashes.json')
 assert all(sha(C/f)==h for f,h in manifest.items()),'Desktop bytes differ from preserved baseline; stop'
 dest=P/'delivery-backup';assert not dest.exists(),'Do not repeat transfer automatically'
 for f in whitelist():
  dst=C/f
  if dst.exists():
   (dest/f).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,dest/f)
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/f,dst)
 # Generated, ignored sections remain a local convenience, not committed artifacts.
 for src in (I/'monolithic/build').rglob('*'):
  if src.is_file() and (src.suffix=='.tex' or src.name=='monolithic_references.bib'):
   dst=C/'rigid-identity-framework/monolithic/build'/src.relative_to(I/'monolithic/build');dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 assert all(sha(C/f)==sha(W/f) for f in whitelist())
 dump(P/'logs/desktop-transfer.json',{'base':BASE,'files':{f:sha(C/f) for f in whitelist()},'backup':str(dest),'all_equal':True})
 print('Transferred only classified files; Desktop bytes equal verified isolated edition.')

elif sys.argv[1]=='desktop-check':
 manifest=js(P/'logs/delivery-manifest.json')
 assert all(sha(C/f)==h for f,h in manifest.items()),'Delivery bytes mismatch'
 protected=js(P/'logs/preservation.json')['protected_sha256']
 assert all(sha(C/f)==h for f,h in protected.items()),'Protected Desktop file changed'
 specs=[('desktop-root-integrity',['node','scripts/verify-canonical-integrity.cjs'],C),('desktop-root-claims',['node','scripts/verify-claim-registry.cjs'],C),('desktop-root-release',['node','scripts/verify-canonical-release.cjs'],C),('desktop-corpus',['node','scripts/validate-corpus.js','--json'],C/'rigid-identity-framework'),('desktop-macros',['node','scripts/validate-macros.js'],C/'rigid-identity-framework'),('desktop-prose',['python','scripts/verify-prose-sync.py'],C/'rigid-identity-framework'),('desktop-chapters',['node','docs/ai-platform-outputs/analysis/AUDITORIA_INTEGRAL_CODEX_2026-11-08/check-monolith.cjs'],C/'rigid-identity-framework'),('desktop-diff',['git','diff','--check'],C)]
 results=[]
 for name,args,cwd in specs:
  r=command(name,args,cwd);results.append(r);print(name,r['exit'],flush=True)
  if r['exit']!=0:dump(P/'logs/desktop-checks.json',results);raise SystemExit(r['exit'])
 dump(P/'logs/desktop-checks.json',results)
 print('Desktop gates and byte-identity checks passed.')
else:raise SystemExit('Unknown mode')
