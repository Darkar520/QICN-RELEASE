from pathlib import Path
import re,json,hashlib,sys
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework'
folders=['paper3','paper4','paper6_predictions_falsation','paper9_phenomenal_bridge_organization','paper10_external_adjudication','monolithic']
rows=[]
for folder in folders:
 name='QICN_MONOLITHIC' if folder=='monolithic' else 'main';s=(I/folder/(name+'.log')).read_text(encoding='utf8',errors='replace');pdf=I/folder/(name+'.pdf')
 row={'folder':folder,'pages':int(re.findall(r'Output written on .*?\((\d+) pages?',s)[-1]),'overfull_hbox':len(re.findall(r'Overfull \\hbox',s)),'overfull_vbox':len(re.findall(r'Overfull \\vbox',s)),'undefined_references':len(re.findall(r'Reference .*?undefined|There were undefined references',s)),'undefined_citations':len(re.findall(r'Citation .*?undefined|There were undefined citations',s)),'duplicate_labels':len(re.findall(r'multiply defined|multiply-defined labels|same identifier',s)),'fatal_errors':len(re.findall(r'^!|Fatal error',s,re.M)),'underfull_hbox':len(re.findall(r'Underfull \\hbox',s)),'underfull_vbox':len(re.findall(r'Underfull \\vbox',s)),'latex_warnings':len(re.findall(r'LaTeX Warning',s)),'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
 rows.append(row)
out={'pdfs':rows,'passed':all(not any(r[k] for k in ['overfull_hbox','overfull_vbox','undefined_references','undefined_citations','duplicate_labels','fatal_errors']) for r in rows),'external_support_certified':False}
(P/'logs/layout.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out,indent=2));sys.exit(not out['passed'])
