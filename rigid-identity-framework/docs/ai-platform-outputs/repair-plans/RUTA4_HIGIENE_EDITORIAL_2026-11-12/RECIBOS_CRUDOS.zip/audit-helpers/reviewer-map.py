from pathlib import Path
import json,re,subprocess
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework';D=I/'docs/ai-platform-outputs/repair-plans/RUTA4_HIGIENE_EDITORIAL_2026-11-12'
aux=(I/'monolithic/QICN_MONOLITHIC.aux').read_text(encoding='utf8');labels={m[1]:(m[2],m[3]) for m in re.finditer(r'\\newlabel\{([^}]+)\}\{\{([^}]+)\}\{([^}]+)\}',aux)}
pages=(P/'logs/monolithic-text.txt').read_text(encoding='utf8').split('\f');start=[i for i,t in enumerate(pages) if re.match(r'^BaseCore\s',t)][0]
assert start==24 and len(pages)-1==440
rows=[json.loads(s) for s in (I/'registry/theorems.jsonl').read_text(encoding='utf8').splitlines()]
chosen=[('basecore','prop:base-wedge-metric-sector'),('paper1','prop:wedge-cartesian-gap'),('paper1','thm:wedge-bilipschitz-gap'),('paper1','prop:wedge-degenerate-controls'),('paper1','prop:wedge-energy-regimes'),('paper5','def:asymmetric-native-plant'),('paper5','thm:asymmetric-native-six'),('paper7','prop:asymmetric-native-life'),('paper7','prop:asymmetric-native-subject'),('paper8','def:indexed-causal-grammar'),('paper8','lem:indexed-causal-closure-loss'),('paper8','def:native-seven-protocol'),('paper8','prop:native-seven-coordinates'),('paper8','lem:native-intervention-selectivity'),('paper8','thm:native-nonempty-subfp'),('bridge','thm:sigma-common-fixed-point'),('bridge','prop:sigma-fibre-truncation'),('bridge','cor:native-indexed-selfreference-boundary'),('paper9','prop:bridge-transport-cycle'),('paper9','cor:native-transport-record'),('paper10','thm:null-forced'),('paper10','thm:coverage-sensitive-leakage'),('basecore','thm:bridge'),('paper3','nonthm:estimator-gap')]
result=[]
for paper,label in chosen:
 r=[r for r in rows if r['paper']==paper and r.get('label')==label];assert len(r)==1,(paper,label);r=r[0]
 prefix='mono:basecore:' if paper=='basecore' else 'mono:bridge:' if paper=='bridge' else 'mono:p'+paper[5:].zfill(2)+':'
 num,page=labels[prefix+label];aux_physical=int(page)+start
 typename={'nontheorem':'Non-Theorem'}.get(r['type'],r['type'].capitalize())
 heading=re.compile(r'^\s*'+re.escape(typename)+r'\s+'+re.escape(num)+r'\s*\(',re.M)
 candidates=[i+1 for i,t in enumerate(pages) if heading.search(t)]
 assert len(candidates)==1,('PDF heading not unique',label,candidates)
 physical=candidates[0];assert abs(physical-aux_physical)<=1,(label,physical,aux_physical)
 page_text=pages[physical-1]
 for word in [w for w in re.findall(r'[A-Za-z]+',r['title']) if len(w)>3][:2]:
  assert word.lower() in page_text.lower(),('heading not found',label,word,physical)
 result.append({'paper':paper,'label':label,'id':r['id'],'title':r['title'],'number_in_volume':num,'printed_page':physical-start,'pdf_page':physical,'aux_page':int(page),'source':r['location']['file'],'line':r['location']['line_start']})
(P/'logs/reviewer-map.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
text='''# Ruta 4 · guía de revisión matemática humana

Edición compilada 2026-11-13, base 5535a5c. Volumen activo:
`rigid-identity-framework/monolithic/QICN_MONOLITHIC.pdf`, 440 páginas.
“PDF” cuenta desde la portada; “impresa” es la numeración árabe del cuerpo.
Hay 24 páginas preliminares. La guía editorial está en la página PDF 3
(iii), el prefacio en PDF 2 y BaseCore comienza en PDF 25 (impresa 1).
Los números se extrajeron del AUX final; las páginas corresponden al
encabezado efectivamente impreso en el PDF. En el lema 8.41 el ancla AUX
queda una página antes del encabezado por el salto tipográfico; aquí se
da su página real (PDF 315, impresa 291), sin alterar etiquetas o matemática.
El Puente es un capítulo sin número después de X; conserva la numeración
histórica de entornos 10.*. Se identifica aquí por capítulo, etiqueta y fuente.

## Itinerario de lectura

1. BaseCore y Papers I–III: tipos, sector de intervención, separación de
   lecturas, testigos externos y límites. Inspeccionar primero la cuña métrica
   y sus contra-controles; no inferir atomicidad desde resistencia sola.
2. V, VII, VIII: seguir la misma planta infinita, su soporte, región segura,
   recuperación frente al pasivo, referencias y gramática de comparación.
   Comprobar el alcance de cada cuantificador antes de interpretar las medidas.
3. Puente y IX: contrastar obstrucción exacta, variante por fibras y transporte
   XOR. El certificado local completo no realiza todos los predicados BPF.
4. IV, VI y X: revisar contratos, controles negativos, información/coste,
   pérdida, cobertura, fuga, población y unidad independiente antes de diseñar
   una campaña. No hay campaña externa ni cierre por compilar el corpus.

## Resultados y localización exacta

Las rutas de fuente de la tabla son relativas a `rigid-identity-framework/`.
El enlace del nombre abre la fuente; el número de página abre el volumen.

| Unidad / resultado | Nº del volumen | Impresa | PDF | Fuente y etiqueta |
|---|---:|---:|---:|---|
'''
for r in result:
 source='../../../../'+r['source'];pdf='../../../../monolithic/QICN_MONOLITHIC.pdf#page='+str(r['pdf_page'])
 text+=f"| {r['paper']} · {r['title']} | {r['number_in_volume']} | {r['printed_page']} | [{r['pdf_page']}]({pdf}) | [{r['source']}:{r['line']}]({source}) · `{r['label']}` |\n"
text+='''
## Separación de niveles de verificación

- **Pruebas analíticas en TeX:** compactitud y topología infinita, cadenas de
  Hausdorff, sectores de deformación, dinámica global, clausura causal y
  admisibilidad de experimentos. Requieren lectura matemática independiente.
- **Lean 4.31.0:** 32 módulos, 250 teoremas públicos en el recibo kernel de
  Ruta 3; en Ruta 4 se comprobaron las 32 huellas sin modificar o recompilar
  Lean. La entrada es `docs/ai-platform-outputs/formal/lean/QICNLean.lean`.
  `QICNEpistemicWedgeStability.lean` formaliza norma euclídea y álgebra de
  brechas, escalas diádicas y resistencia. `QICNEpistemicSubfp.lean` formaliza
  ortogonalidad en cubo de signos, pérdidas, umbrales y controles finitos.
  `QICNFiniteP4.lean` contiene núcleos de punto fijo, truncamiento, XOR y
  abstención. No cubren toda la construcción infinita ni toda la gramática.
  Sólo axiomas estándar; ausencia de sorryAx en el recibo kernel preservado.
- **Python:** `scripts/verify-math-regressions.py` ejecuta 32 suites. Las de
  Ruta 3 son `check_wedge_stability.py` y `check_native_subfp.py` en su carpeta
  de fase. Sus controles racionales complementan la prueba analítica; no
  certifican universalidad ni interpretación subjetiva.
- **Ingeniería documental:** compilación, citas, etiquetas, registro, huellas y
  comparación LF/CRLF verifican conservación y reproducción editorial.
  No constituyen revisión por pares ni datos externos.

## Preguntas que deben permanecer abiertas

1. Revisar la adecuación y dependencia representacional de la gramática
   causal/computacional frente a rivales más amplios. Un emulador al mismo
   coste e información elimina la ventaja; no es un rival ya derrotado.
2. Revisar los argumentos infinitos de la cuña y de la planta, y la
   identificación de controles, referencias y calibraciones. La energía del
   actuador es operacional, sin medición física en julios.
3. La Parte IX de BaseCore (puente discreto) fija energía/fase auxiliares;
   acoplar su evolución exige hipótesis y un teorema nuevos. No confundir
   esa Parte IX con el Paper IX de transporte entre modos.
4. Estimar empíricamente K_i, omega_i, epsilon_i y Delta* para una población,
   observación e intervención concretas. Los modelos constructivos no
   resuelven su identificación física general.
5. Instanciar el resto de predicados BPF, sus rivales e intervenciones, y
   realizar revisión humana y experimentos independientes. Cualquier fase en
   QICN-SYSTEM será separada; no se accedió a ese proyecto.

Los veredictos conservan INTERNAL_DIAGNOSTIC_PASS_SYNTHETIC_ONLY,
BLOCKED_MULTIPLE_GATES y BLOCKED_FOUNDATION_FIRST_GATES.
`external_support_certified=false`.
'''
(D/'GUIA_REVISOR.md').write_text(text,encoding='utf8')
print('24 theorem/source/page entries; reader guide PDF 3; main offset',start)
