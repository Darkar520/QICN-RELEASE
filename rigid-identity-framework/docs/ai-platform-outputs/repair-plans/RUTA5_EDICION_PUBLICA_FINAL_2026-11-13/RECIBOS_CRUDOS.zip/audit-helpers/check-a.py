from pathlib import Path
import json,re,ast,hashlib,difflib
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework';B=P/'baseline/rigid-identity-framework'
old=Path('E:/QICN-PRESERVACION/2026-11-12-ruta4/check-preservation.py').read_text()
fn=next(x for x in ast.parse(old).body if isinstance(x,ast.FunctionDef) and x.name=='math_fragments');ns={'re':re};exec(compile(ast.Module(body=[fn],type_ignores=[]),'<math-parser>','exec'),ns)
strip=lambda s:re.sub(r'(?<!\\)%[^\n]*','',s)
result=[]
for f in sorted(list(B.glob('basecore/**/*.tex'))+list(B.glob('paper*/**/*.tex'))):
 rel=f.relative_to(B);a=f.read_text(encoding='utf-8-sig');b=(I/rel).read_text(encoding='utf-8-sig')
 aa=ns['math_fragments'](strip(a));bb=ns['math_fragments'](strip(b))
 labels=lambda s:re.findall(r'\\(label|ref|eqref)\{([^}]+)\}',strip(s))
 cursor=0;extra=[]
 for fragment in bb:
  if cursor<len(aa) and fragment==aa[cursor]:cursor+=1
  else:extra.append(fragment)
 allowed={'basecore/core/sections/09_canonical_ledgers.tex':['$\\norm{K}<1$','$\\U$'],'paper8_first_person_subjectivity/main.tex':['$\\Subfp$']*3,'paper9_phenomenal_bridge_organization/main.tex':['$\\PhiBridge$','$\\GateBridge$']}
 preserved=cursor==len(aa) and extra==allowed.get(rel.as_posix(),[])
 row={'file':str(rel),'math_count_before':len(aa),'math_count_after':len(bb),'math_equal':aa==bb,'all_previous_math_preserved':preserved,'additional_existing_symbol_references':extra,'labels_refs_equal':labels(a)==labels(b)}
 if aa!=bb:row['math_diff']=list(difflib.unified_diff(aa,bb))
 result.append(row)
(P/'logs/math-preservation-a.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
bad=[x for x in result if not x['all_previous_math_preserved'] or not x['labels_refs_equal']]
print(json.dumps(bad,ensure_ascii=False,indent=2));assert not bad,'Repair mathematical differences before building'
c=I/'monolithic/preamble/source-contract.json';j=json.loads(c.read_text(encoding='utf8'));changed=[]
for rel,h in j['sources'].items():
 pre=(I/rel).read_text(encoding='utf-8-sig').split(r'\begin{document}')[0];actual=hashlib.sha256(pre.encode()).hexdigest()
 if actual!=h:changed.append({'file':rel,'before':h,'after':actual});j['sources'][rel]=actual
assert not changed or [x['file'] for x in changed]==['paper10_external_adjudication/main.tex'],changed
if changed:
 c.write_text(json.dumps(j,indent=2)+'\n',encoding='utf8')
 (P/'logs/preamble-change.json').write_text(json.dumps(changed,indent=2),encoding='utf8')
print('23-source math and label/reference parity verified. Only Paper X preamble contract updated.')
