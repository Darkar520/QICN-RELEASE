from pathlib import Path
import subprocess,os,json,time,sys
p=Path(__file__).resolve().parent;inner=p/'workspace/rigid-identity-framework';phase=sys.argv[1]
env=os.environ.copy();env['TEMP']=env['TMP']=str(p/'tmp');env['npm_config_cache']=str(p/'npm-cache')
records=[];logdir=p/'logs'/phase;logdir.mkdir(parents=True,exist_ok=True)
for folder in [x for x in sys.argv[2:] if x!='--papers-only']:
 basename='BASECORE' if folder=='basecore' else 'main'
 commands=[['pdflatex','-interaction=nonstopmode','-halt-on-error',basename+'.tex']]
 if 'biblatex' in (inner/folder/(basename+'.tex')).read_text(encoding='utf-8-sig').split('\\begin{document}')[0]:commands.append(['biber',basename])
 commands += [['pdflatex','-interaction=nonstopmode','-halt-on-error',basename+'.tex'],['pdflatex','-interaction=nonstopmode','-halt-on-error',basename+'.tex']]
 for j,cmd in enumerate(commands):
  start=time.monotonic()
  with (logdir/f'{folder}-{j}.log').open('w',encoding='utf-8') as log:run=subprocess.run(cmd,cwd=inner/folder,env=env,stdout=log,stderr=subprocess.STDOUT)
  records.append({'folder':folder,'command':cmd,'exit':run.returncode,'seconds':round(time.monotonic()-start,2)})
  (logdir/'compile.json').write_text(json.dumps(records,indent=2))
  print(folder,j,run.returncode,flush=True)
  if run.returncode:
   print((logdir/f'{folder}-{j}.log').read_text(errors='replace')[-4500:]);raise SystemExit(run.returncode)
if '--papers-only' in sys.argv:raise SystemExit(0)
with (logdir/'monolithic.log').open('w',encoding='utf-8') as log:run=subprocess.run(['npm.cmd','run','compile:monolithic'],cwd=inner,env=env,stdout=log,stderr=subprocess.STDOUT)
records.append({'folder':'monolithic','command':['npm.cmd','run','compile:monolithic'],'exit':run.returncode})
(logdir/'compile.json').write_text(json.dumps(records,indent=2));print('monolithic',run.returncode,flush=True)
if run.returncode:
 print((logdir/'monolithic.log').read_text(errors='replace')[-4500:]);raise SystemExit(run.returncode)
