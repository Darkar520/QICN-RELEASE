from pathlib import Path
import json,re,hashlib,zipfile,shutil
P=Path(__file__).resolve().parent;W=P/'workspace';I=W/'rigid-identity-framework';D=I/'docs/ai-platform-outputs/repair-plans/RUTA5_EDICION_PUBLICA_FINAL_2026-11-13'
read=lambda f:f.read_text(encoding='utf-8-sig')
js=lambda f:json.loads(read(f))
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
pdfs=js(P/'logs/pdf-audit.json');gates=js(P/'logs/closure-gates/commands.json');assert len(pdfs)==13 and len(gates)==9 and all(x['exit']==0 for x in gates)
assert all(x['metadata']['Author'].strip()=='Johnny Andrey Pérez Ramírez' and x['last_note_after_references'] and x['authorial_note_body_count']==1 and not x['scan_hits'] and not any(x['log'].values()) for x in pdfs)
protected=js(P/'logs/protected-sha256.json');assert all(sha(W/f)==h for f,h in protected.items())
reg=js(P/'logs/registry-preservation.json');assert reg['ids_preserved'] and reg['curation_preserved'] and reg['final_ids']==906 and reg['macro_count']==383
legacy=js(I/'docs/reports/V35_ALL_LEGACY_VERIFICATION.json');assert legacy['external_support_certified'] is False
lf=js(P/'logs/line-endings.json');assert lf['passed'] and len(lf['results'])==12
fixes=[]
for name in ['remediation-a.json','remediation-a2.json','remediation-a3.json','remediation-bridge.json','remediation-pdf-residue.json']:
 fixes.append({'receipt':name,'content':js(P/'logs'/name)})
report='''# Ruta 5 · edición pública final: ejecución y recepción

Base: `2d4fbcc0bf436a181cd9371d1ec3408c4f9999c5`. Fecha: 2026-11-13.
Se auditaron las 17 fuentes recibidas, preservadas antes de intervenir junto
con el prerregistro original. Trabajo y temporales en E:, con entrega selectiva
a la copia ordenada del Escritorio una vez terminada la revisión pre-push.

## Discrepancias y correcciones

La [adenda forense](ADENDA_AUDITORIA_CODEX.md) describe los hallazgos del
revisor aislado y su remediación: fórmula y macro restauradas, separación del
par testigo restituida, eliminación de atribuciones bibliográficas sin fuente,
garantías de reducción sin exageración de independencia, código ejecutable
para reproducir resultados y ámbitos normativos de B4–B6 conservados.
También se corrigieron el subtítulo duplicado de IX y una fila de VI con un
separador sobrante. La compilación descubrió un `item` fuera de una lista en
Puente: se restauró el párrafo. El escaneo de los PDF detectó un identificador
AUDIT_MASTER escapado en IX: se sustituyó por “audit coverage”. Se conservaron
los fallos y comandos previos; los verificadores no se modificaron.

La [trazabilidad exacta](TRAZABILIDAD_EDITORIAL.json) conserva los 482 bloques
antes/después, rutas e identificadores retirados de los manuscritos y sus
correspondencias públicas. Los nombres de niveles describen dependencias;
ninguno implica ejecución de una campaña. Los controles conservan su ámbito
interno, parcialmente cegado y de reproducción en el mismo equipo.

## Preservación y alcance

Se mantienen los 906 IDs y 383 macros del registro; 118 filas actualizan
localización o extracto editorial sin sustituir su curación, dependencias o
historia. Las secuencias de etiquetas/ref/eqref se conservan en 23 fuentes.
Todas las expresiones matemáticas previas permanecen en orden; se registran
aparte siete menciones nuevas de símbolos ya existentes en prosa. No se
afirma igualdad textual absoluta de cuerpos que recibieron correcciones de
gramática o procedencia. La fórmula Score_{v4.5} conserva su identificador
histórico: eliminar números a costa de alterar matemática sería una regresión.

Los 32 archivos Lean y los 82 archivos congelados/legados coinciden byte a
byte con el estado recibido. Se dejó Lean intacto para Ruta 6; no se ejecutó
un nuevo kernel ni se atribuyó mecanización nueva a esta edición. El cambio
de preámbulo de X documenta autor e información PDF, con macro sectionstatus
conservada sin usos; sólo se actualiza su hash fuente en el contrato auditado.

Las notas de autoría declaran la historia suministrada por el autor y su
responsabilidad intelectual. Cada documento independiente tiene una nota
después de la bibliografía. El ensamblador exige una por fuente, las retira
de los capítulos y añade una sola al final del volumen; la entrada del índice
no es una segunda nota sustantiva.

## Los 13 PDF

Autor PDF comprobado exactamente: Johnny Andrey Pérez Ramírez. Los títulos
completos, pdfinfo, SHA-256 y textos UTF-8 están en el recibo y archivo crudo.
Todos tienen una nota al cierre, cero hallazgos de rutas locales o archivos
internos, marcas de borrador, identificadores de iteración y muletillas
explícitas del escaneo; cero caracteres corruptos detectados. Una búsqueda
finita no certifica ausencia de todo posible defecto estilístico o semántico.

| PDF | Páginas | Nota al cierre | Escaneo / log |
|---|---:|---:|---|
'''
for x in pdfs:report+=f"| `{x['file'].replace(chr(92),'/')}` | {x['pages']} | 1 | 0 hallazgos / 0 errores o Overfull |\n"
report+='''
Los 13 PDF se compilaron con pdflatex y biber donde corresponde, seguido de
dos pases finales de pdflatex. X no usa biblatex. VI, IX y Puente tuvieron
reconstrucciones selectivas después de correcciones, junto con el monolito.
No se anuncia cero advertencias totales: los Underfull y ajustes normales
de colocación permanecen documentados en los logs.

## Verificación y fronteras científicas

Raíz 3/3, release 6/6, suites matemáticas 32/32, corpus y macros sin bloqueos,
prosa sin errores, nonclaims sin infracciones y capítulos 12/12 LF/CRLF.
El primer comparador encontró un capítulo VI anterior a la última edición:
se regeneró desde fuentes, sin modificar su criterio, y volvió a 12/12.
Las salidas literales de los tres verificadores y de los seis pasos release
se preservan en VERIFICACION.json y RECIBOS_CRUDOS.zip.

Veredictos crudos: v25/v26 `INTERNAL_DIAGNOSTIC_PASS_SYNTHETIC_ONLY`;
v27/v28/v30 `BLOCKED_MULTIPLE_GATES`; v31 `BLOCKED_FOUNDATION_FIRST_GATES`.
**external_support_certified=false**. No se accedió al runtime.

Siguen abiertos el acoplamiento dinámico de los auxiliares energéticos/fase,
las brechas de estimadores y calibración física de III, los emuladores
irrestrictos, la clase BPF completa, revisión humana e investigación empírica.
El ensamblado y la auditoría automatizada no resuelven esas obligaciones.

## Revisión y publicación

La revisión aislada inicial y la segunda pasada de fuentes exigieron y
comprobaron reparaciones. La aprobación final pre-push debe cotejar estos
artefactos y recibos con la edición a publicar. No se realizará push antes
de ese dictamen. Ruta 6 queda como programa separado posterior, con 419
entradas theorem/proposition/lemma/corollary por clasificar y mecanizar sin
redefiniciones silenciosas; no se presentan como 419 pruebas Lean actuales.
'''
(D/'EJECUCION.md').write_text(report,encoding='utf8')
readme='''# Monolithic Volume

Edición pública Ruta 5, compilada el 13 de noviembre de 2026: **438 páginas**.
Ensambla BaseCore, Papers I–X y Puente desde sus fuentes independientes.
La guía de lectura del prefacio explica las dependencias y límites de la
verificación. La nota de autoría aparece una sola vez al cierre del volumen.

`QICN_MONOLITHIC.tex` es generado: editar las fuentes o el ensamblador,
`scripts/build-monolithic-volume.js`, y reconstruir desde el paquete teórico:

```powershell
npm run build:monolithic
npm run compile:monolithic
```

`preamble/source-contract.json` comprueba preámbulos y personalizaciones;
no debe actualizarse para ocultar deriva. Ruta 5 documenta sólo la nueva
autoría y metadatos de X. Los capítulos y bibliografía bajo `build/` son
productos derivados, no fuentes alternativas.

Esta edición pasó comparación fuente/capítulo 12/12 en LF y CRLF. Los
13 PDF del corpus activo compilaron sin errores fatales, referencias/citas
indefinidas, etiquetas duplicadas u Overfull. Los escaneos completos, páginas,
metadatos y huellas constan en el
[informe de Ruta 5](../docs/ai-platform-outputs/repair-plans/RUTA5_EDICION_PUBLICA_FINAL_2026-11-13/EJECUCION.md).
No se presentan los avisos Underfull como errores resueltos ni se atribuye
una aprobación nueva a un gate tipográfico histórico.

Las fuentes y pruebas conservan su ámbito. Lean queda intacto y su siguiente
fase está en el roadmap. Revisión matemática humana, calibración y evidencia
independiente siguen pendientes. **external_support_certified=false**.
'''
(I/'monolithic/README.md').write_text(readme,encoding='utf8')
receipt={'phase':'Ruta 5','status':'AWAITING_FINAL_ISOLATED_REVIEW','baseline':'2d4fbcc0bf436a181cd9371d1ec3408c4f9999c5','external_support_certified':False,'pdfs':pdfs,'gates':gates,'raw_root_outputs':{n:read(P/'logs/closure-gates'/f'{n}.log') for n in ['root-integrity','root-claims','root-release']},'release_steps':legacy,'registry':reg,'line_endings':lf,'protected_sha256':protected,'repairs':fixes,'lean_rebuilt':False}
(D/'VERIFICACION.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf8')
print('Final report, README and receipt prepared for isolated review.')
