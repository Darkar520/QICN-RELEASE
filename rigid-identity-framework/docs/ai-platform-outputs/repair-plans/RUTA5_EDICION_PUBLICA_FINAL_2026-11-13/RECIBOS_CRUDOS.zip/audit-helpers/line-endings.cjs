const fs=require('fs'),path=require('path'),vm=require('vm'),crypto=require('crypto');
const P=__dirname,I=path.join(P,'workspace/rigid-identity-framework');
const f=path.join(I,'scripts/build-monolithic-volume.js');
function assembled(crlf){
 const adapt=s=>crlf?s.replace(/\r?\n/g,'\r\n'):s.replace(/\r\n/g,'\n');
 const mock=Object.create(fs);mock.readFileSync=(p,opts)=>{const x=fs.readFileSync(p,opts);return typeof x==='string'&&String(p).endsWith('.tex')?adapt(x):x;};
 const ctx={require:n=>n==='fs'?mock:require(n),module:{},__dirname:path.dirname(f),process,console};vm.createContext(ctx);
 vm.runInContext(fs.readFileSync(f,'utf8')+'\nglobalThis.audit={SOURCES,bodyOf,expandLocalInputs,stripEncodingNoise,rewriteAppendixForMonolithic,namespaceLabelsAndRefs,applyMonolithicLayoutTransforms,wrapSection};',ctx);
 const a=ctx.audit;return a.SOURCES.map(s=>{const raw=mock.readFileSync(path.join(I,s.relPath),'utf8');const b=a.rewriteAppendixForMonolithic(a.expandLocalInputs(a.stripEncodingNoise(a.bodyOf(raw)),s.relPath));return {source:s.relPath,text:a.wrapSection(s,a.applyMonolithicLayoutTransforms(a.namespaceLabelsAndRefs(b,s),s.relPath))+'\n',section:s.sectionName}});
}
const lf=assembled(false),crlf=assembled(true),normalize=s=>s.replace(/\r\n/g,'\n');
const results=lf.map((a,n)=>{const disk=fs.readFileSync(path.join(I,'monolithic/build/sections',a.section),'utf8');return{source:a.source,lf_equal:normalize(a.text)===normalize(disk),crlf_equal:normalize(crlf[n].text)===normalize(disk),lf_crlf_equal:a.text===crlf[n].text};});
const out={results,passed:results.every(r=>r.lf_equal&&r.crlf_equal&&r.lf_crlf_equal),external_support_certified:false};
fs.writeFileSync(path.join(P,'logs/line-endings.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out,null,2));if(!out.passed)process.exit(1);
