from pathlib import Path
import re,json
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework';B=P/'baseline/rigid-identity-framework';OLD=Path('E:/QICN-PRESERVACION/2026-11-12-ruta4/workspace/rigid-identity-framework')
D=I/'docs/ai-platform-outputs/repair-plans/RUTA5_EDICION_PUBLICA_FINAL_2026-11-13'
trace=json.loads((D/'TRAZABILIDAD_EDITORIAL.json').read_text(encoding='utf8'))
oldsections=OLD/'monolithic/build/sections';newsections=I/'monolithic/build/sections'
folders=['basecore','paper1','paper2','paper3','paper4','paper5_operational_consciousness','paper6_predictions_falsation','paper7_operational_life_subjecthood','paper8_first_person_subjectivity','paper9_phenomenal_bridge_organization','paper10_external_adjudication','paper_bridge_operational_subjecthood']
sectionnames=sorted(x.name for x in newsections.glob('*.tex'));assert len(sectionnames)==12
sectionmap=dict(zip(folders,sectionnames))
def norm(s):
 s=re.sub(r'(?<!\\)%[^\n]*','',s)
 s=re.sub(r'\\detokenize\{([^{}]*)\}',r'\1',s).replace(r'\allowbreak{}','').replace(r'\-','').replace(r'\_','_')
 s=re.sub(r'\\(?:label|ref|eqref|cite|addcontentsline)\{[^{}]*\}(?:\{[^{}]*\}){0,2}',' ',s)
 s=re.sub(r'\\(?:begin|end)\{[^{}]*\}(?:\[[^\]]*\])?',' ',s)
 s=re.sub(r'\$[^$]*\$|\\\[[\s\S]*?\\\]',' ',s)
 s=re.sub(r'\\[A-Za-z@]+\*?',' ',s)
 return ' '.join(re.findall(r'[A-Za-z0-9_]+',s)).lower()
cache={};rows=[]
for n,h in enumerate(trace['hunks']):
 rel=h['file'];folder=rel.split('/')[0]
 if rel not in cache:
  a=(B/rel).read_text(encoding='utf8');b=(I/rel).read_text(encoding='utf8')
  assert a==(OLD/rel).read_text(encoding='utf8'),rel
  cache[rel]=(a,b,norm(a),norm(b),norm((oldsections/sectionmap[folder]).read_text(encoding='utf8')),norm((newsections/sectionmap[folder]).read_text(encoding='utf8')))
 a,b,sa,sb,ca,cb=cache[rel]
 row={'hunk':n,'file':rel,'line_counts':[]}
 for side in ['before','after']:
  for line in h[side].splitlines():
   t=norm(line)
   if not t:continue
   entry={'side':side,'fragment':t,'source_before':sa.count(t),'source_after':sb.count(t),'chapter_before':ca.count(t),'chapter_after':cb.count(t)}
   source_line=h[side+'_lines'][0]
   note='AUTHORIAL_NOTE' in h[side] or 'Authorial Note and Methodological Provenance' in h[side] or 'The conception, theoretical direction' in h[side]
   preamble=r'\begin{document}' in a and source_line<=len(a.split(r'\begin{document}')[0].splitlines())
   if note:entry['classification']='authorial-note: chapter omission intentional; one copy checked at volume end'
   elif preamble:entry['classification']='preamble: standalone metadata, deliberately omitted from extracted chapters'
   elif len(t.split())<4:entry['classification']='short syntax/title/identifier fragment; full chapter byte comparator covers layout'
   else:
    entry['classification']='prose'
    entry['propagated']=entry['chapter_before' if side=='before' else 'chapter_after']>0
   row['line_counts'].append(entry)
 rows.append(row)
bad=[{'hunk':r['hunk'],'file':r['file'],**e} for r in rows for e in r['line_counts'] if e.get('propagated') is False]
out={'method':'All 488 source hunks, with normalized lexical fragment counts before/after in source and corresponding full chapter. Explicit exceptions for preambles, relocated authorial note and short layout fragments; independently enforced full chapter equality.','hunks':rows,'unresolved_prose_fragments':bad,'external_support_certified':False}
(P/'logs/phrase-counts.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print('hunks',len(rows),'unresolved',len(bad));print(json.dumps(bad[:12],ensure_ascii=True,indent=2))
