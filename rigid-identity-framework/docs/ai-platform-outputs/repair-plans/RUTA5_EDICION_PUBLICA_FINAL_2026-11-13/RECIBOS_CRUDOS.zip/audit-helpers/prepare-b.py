from pathlib import Path
import re,json,hashlib,shutil,ast
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework'
f=I/'paper9_phenomenal_bridge_organization/main.tex';s=f.read_text(encoding='utf8')
s=s.replace('Tier~B4 requires empirical calibration scales to be bound for the symbolic threshold slots, finalizes the functional','Tier~B4 requires binding empirical calibration scales for the symbolic threshold slots, finalizing the functional').replace(r'$\PhiBridge$, evaluates the conjunctive gate',r'$\PhiBridge$, evaluating the conjunctive gate').replace(r'$\GateBridge$, and authorizes root verdict schemas',r'$\GateBridge$, and authorizing root verdict schemas')
f.write_text(s,encoding='utf8',newline='\n')
f=I/'scripts/build-monolithic-volume.js';s=f.read_text(encoding='utf8')
old='function applyMonolithicLayoutTransforms(content, relPath) {\n'
assert old in s
s=s.replace(old,old+r'''  // Authorial provenance is printed once after the collected bibliography.
  const notes = content.match(/% BEGIN_AUTHORIAL_NOTE[\s\S]*?% END_AUTHORIAL_NOTE/g) || [];
  if (notes.length !== 1) throw new Error("Expected one authorial note in " + relPath);
  content = content.replace(notes[0], "");
''')
start=s.index('const EDITORIAL_PREFACE');end=s.index('function bodyOf',start)
pref=s[start:end].replace(r'implementation study in \texttt{QICN-SYSTEM} is a separate phase; no runtime',r'implementation study of the software system is a separate phase; no runtime')
s=s[:start]+pref+s[end:]
needle='    "\\\\printbibliography[heading=bibintoc]",'
assert needle in s
note=(P/'authorial-note.tex').read_text(encoding='utf8')
constant='const AUTHORIAL_NOTE = String.raw`'+note+'`;\n\n'
s=s.replace('function bodyOf(content) {',constant+'function bodyOf(content) {')
s=s.replace(needle,needle+'\n    "\\\\clearpage",\n    AUTHORIAL_NOTE,')
f.write_text(s,encoding='utf8',newline='\n')
# Update just the audited source preamble hash for explicit author/PDF metadata.
c=I/'monolithic/preamble/source-contract.json';j=json.loads(c.read_text(encoding='utf8'))
src=(I/'paper10_external_adjudication/main.tex').read_text(encoding='utf8').split(r'\begin{document}')[0]
# Use the assembler's own normalization rather than inventing a new hash contract.
script=(I/'scripts/build-monolithic-volume.js').read_text(encoding='utf8')
(P/'logs/contract-before.json').write_text(json.dumps(j,indent=2),encoding='utf8')
print('Assembler ready. Check its digest expression before changing contract.')
for n,line in enumerate(script.splitlines()):
 if 'digest' in line or 'preambleHash' in line:print(n+1,line)
# Reuse the established build/log runners with fresh directories.
for name in ['compile.py','verify_stage.py','line-endings.cjs']:
 shutil.copy2(Path('E:/QICN-PRESERVACION/2026-11-12-ruta4')/name,P/name)
(P/'tmp').mkdir(exist_ok=True);(P/'npm-cache').mkdir(exist_ok=True)
