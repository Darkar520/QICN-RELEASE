const fs=require('fs'),path=require('path');
const P=__dirname,I=path.join(P,'workspace/rigid-identity-framework'),B=path.join(P,'baseline/rigid-identity-framework');
const lib=require(path.join(I,'scripts/registry-lib'));
const rows=p=>fs.readFileSync(p,'utf8').trim().split(/\r?\n/).map(JSON.parse);
const old=rows(path.join(B,'registry/theorems.jsonl'));
const before=lib.extractFormalEnvironments(B),after=rows(path.join(P,'logs/extracted-theorems.jsonl'));
console.log({curated:old.length,baseline_extract:before.length,new_extract:after.length});
fs.writeFileSync(path.join(P,'logs/baseline-extracted.json'),JSON.stringify(before,null,2));
if(process.argv.includes('--inspect'))process.exit(0);
if(old.length!==before.length||old.length!==after.length)throw Error('Count mismatch');
const groups=a=>{const m=new Map();for(const r of a){const k=r.location.file+'|'+r.type; if(!m.has(k))m.set(k,[]);m.get(k).push(r)}for(const v of m.values())v.sort((a,b)=>a.location.line_start-b.location.line_start);return m;};
const go=groups(old),gb=groups(before),ga=groups(after),out=[],edits=[];
const titleChanges=new Map([['v24 consistency patch','Infimum convention and scope'],['v24 correction of the former Step 2','Extension witnesses are an independent hypothesis']]);
for(const [k,orig] of go){const b=gb.get(k),a=ga.get(k);if(!b||!a||orig.length!==b.length||orig.length!==a.length)throw Error('Group mismatch '+k);
 for(let n=0;n<orig.length;n++){
  const o=orig[n],x=b[n],y=a[n];
  if(o.label!==x.label||x.label!==y.label)throw Error('Label mismatch '+o.id);
  if(o.location.line_start!==x.location.line_start)throw Error('Baseline source mismatch '+o.id);
  const r=structuredClone(o);r.location=y.location;
  if(x.title!==y.title)r.title=y.title;
  if(x.statement_tex!==y.statement_tex){r.statement_tex=y.statement_tex;r.statement=y.statement;}
  out.push(r);
  if(JSON.stringify(r)!==JSON.stringify(o))edits.push({id:o.id,location_before:o.location,location_after:r.location,title_before:o.title,title_after:r.title,statement_before:x.statement_tex,statement_after:y.statement_tex});
 }
}
const byid=new Map(out.map(r=>[r.id,r]));const ordered=old.map(r=>byid.get(r.id));
lib.writeJsonl(path.join(I,'registry/theorems.jsonl'),ordered);
const om=rows(path.join(B,'registry/macros.jsonl')),am=rows(path.join(P,'logs/extracted-macros.jsonl'));
const mg=groups(om),ag=groups(am),macros=[];
// Macro records have no theorem ID. Preserve original row order and all fields
// except source line locations, matched by file, name and exact definition.
const key=r=>JSON.stringify([r.location.file,r.name,r.definition,r.command]);
const q=new Map();for(const r of am){const k=key(r);if(!q.has(k))q.set(k,[]);q.get(k).push(r)}
for(const o of om){const candidates=q.get(key(o));if(!candidates?.length)throw Error('Macro lost '+o.name);const y=candidates.shift();macros.push({...o,location:y.location})}
if(macros.length!==am.length||[...q.values()].some(a=>a.length))throw Error('Macro count');
lib.writeJsonl(path.join(I,'registry/macros.jsonl'),macros);
const report={original_ids:old.length,final_ids:ordered.length,ids_preserved:old.every(r=>byid.has(r.id)),new_or_removed_ids:0,changes:edits,macro_count:macros.length,curation_preserved:true,external_support_certified:false};
fs.writeFileSync(path.join(P,'logs/registry-preservation.json'),JSON.stringify(report,null,2));
console.log({preserved_ids:ordered.length,relocations:edits.length,macros:macros.length});
