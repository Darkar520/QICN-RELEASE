from pathlib import Path
import json,re
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework';B=P/'baseline/rigid-identity-framework'
changes=[]
def edit(rel,old,new):
 f=I/rel;s=f.read_text(encoding='utf-8-sig');assert old in s,(rel,old)
 changes.append({'file':rel,'before':old,'after':new,'occurrences':s.count(old)})
 f.write_text(s.replace(old,new),encoding='utf8',newline='\n')
edit('paper4/main.tex',r'\mathrm{Score}_{\mathrm{comp}}',r'Score_{v4.5}')
edit('paper10_external_adjudication/main.tex',r'\newcommand{\codestate}',r'\newcommand{\sectionstatus}[1]{\paragraph{Section status.}\texttt{\detokenize{#1}}.}'+'\n'+r'\newcommand{\codestate}')
edit('paper3/main.tex','An older literature convention used a supremum notation for $\\MO$. That notation is superseded here.','The supremum notation is superseded by the following infimum convention.')
edit('paper6_predictions_falsation/main.tex','a separately calibrated witness pair','an independently separated and calibrated witness pair')
edit('paper6_predictions_falsation/main.tex','uncalibrated','earlier')
edit('paper6_predictions_falsation/main.tex','blinded comparator scoring, label-blinded ordering, and independent-seed replication','stricter internal scoring, partially blinded ordering, and same-host replication across execution profiles')
edit('paper6_predictions_falsation/main.tex','removes live generator-state dependence present in the initial baseline','reduces live generator-state dependence present in the initial baseline')
edit('paper6_predictions_falsation/main.tex','would eliminate same-lineage measurement dependence','would reduce same-lineage measurement dependence')
edit('paper6_predictions_falsation/main.tex','Blinded & stress pass &','Partially blinded stress evaluation &')
edit('paper6_predictions_falsation/main.tex','preregistered thresholds','thresholds fixed before evaluation')
f=I/'paper9_phenomenal_bridge_organization/main.tex';s=f.read_text(encoding='utf8');title=r'\subsection{Why Paper 9 is still needed now}';assert s.count(title)==2
s=s.replace(title+'\n','',1);f.write_text(s,encoding='utf8',newline='\n');changes.append({'file':str(f.relative_to(I)),'repair':'Remove first duplicated subsection; preserve the three-part argument.'})
edit('basecore/core/sections/06_structural_classes_and_dynamics.tex','Stage 2 / Stage 3 comparative programs','empirical comparative programs')
# Restore the registered domain and conclusion of the package-membership proposition.
audit=json.loads((P/'logs/initial-formal-audit.json').read_text())
for x in audit:
 if x['file'].endswith('paper9_phenomenal_bridge_organization/main.tex'):
  for y in x['formal_differences']:
   if y['index'] in [74,75]:edit('paper9_phenomenal_bridge_organization/main.tex',y['after'],y['before'])
# Author-provided provenance, without an independently verified originality claim.
note=r'''% BEGIN_AUTHORIAL_NOTE
\section*{Authorial Note and Methodological Provenance}
\addcontentsline{toc}{section}{Authorial Note and Methodological Provenance}
The conception, theoretical direction, mathematical architecture, development,
and integration of the QICN research programme were undertaken by a single
independent researcher, Johnny Andrey P\'erez Ram\'irez, over more than one year.
This account of provenance is supplied by the author. Several artificial
intelligence systems and formal verification tools assisted with technical
drafting, proof exploration, consistency checks, and mechanized kernels under
his direction. The author retains intellectual responsibility for the
programme, its claims, and any remaining errors. Analytical manuscript proofs,
machine-checked kernels, and internal tests have distinct scopes; independent
mathematical review and empirical validation remain separate obligations.
\texttt{external\_support\_certified=false}.
% END_AUTHORIAL_NOTE'''
roots=[I/'basecore/BASECORE.tex']+[p/'main.tex' for p in I.glob('paper*') if (p/'main.tex').exists()]
assert len(roots)==12
for f in roots:
 s=f.read_text(encoding='utf-8-sig');m=re.search(r'% BEGIN_AUTHORIAL_NOTE[\s\S]*?% END_AUTHORIAL_NOTE',s);assert m
 s=s[:m.start()]+s[m.end():];s=s.replace(r'\end{document}',note+'\n\n'+r'\end{document}')
 f.write_text(s,encoding='utf8',newline='\n')
changes.append({'files':[str(f.relative_to(I)) for f in roots],'repair':'Consistent bounded author-provided provenance placed after bibliography at document end.'})
(P/'logs/remediation-a.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2),encoding='utf8')
(P/'authorial-note.tex').write_text(note,encoding='utf8')
print('Phase A repairs applied in isolated copy; original Desktop edits preserved.')
