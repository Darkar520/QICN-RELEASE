from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework'
records=[]
def edit(rel,a,b):
 f=I/rel;s=f.read_text(encoding='utf8');assert a in s,(rel,a)
 f.write_text(s.replace(a,b),encoding='utf8',newline='\n');records.append({'file':rel,'before':a,'after':b})
edit('paper6_predictions_falsation/main.tex','the evaluator specification and threshold records','the executable evaluator code and threshold records')
edit('paper6_predictions_falsation/main.tex','the analysis procedures','the executable analysis scripts')
edit('basecore/core/sections/06_structural_classes_and_dynamics.tex','non-convex extension classes thresholded over operational regimes','non-convex extension classes')
edit('paper9_phenomenal_bridge_organization/main.tex','Tier~B4 binds empirical calibration scales','Tier~B4 requires empirical calibration scales to be bound')
edit('paper9_phenomenal_bridge_organization/main.tex','Tier~B5 integrates bridge records into condition-, batch-, and campaign-level governance','Tier~B5 requires bridge records to be integrated into condition-, batch-, campaign-, candidate-, and audit-facing governance')
edit('paper9_phenomenal_bridge_organization/main.tex','Tier~B6 executes comprehensive end-to-end verification and readiness classification','Tier~B6 requires comprehensive end-to-end verification and readiness classification')
edit('paper9_phenomenal_bridge_organization/main.tex',r'\paragraph{Stage 2: $\PiW$ and $\PiT$.}',r'\paragraph{Measurement step 2: $\PiW$ and $\PiT$.}')
edit('paper9_phenomenal_bridge_organization/main.tex',r'\paragraph{Stage 3: $\PiA$ and $\PiE$.}',r'\paragraph{Measurement step 3: $\PiA$ and $\PiE$.}')
(P/'logs/remediation-a2.json').write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf8')
protected={f:h for f,h in json.loads((P/'logs/initial-working-hashes.json').read_text()).items() if f.startswith(('release/','corpus/','artifacts/','rigid-identity-framework/canonical_core_legacy/')) or f.endswith('.lean')}
assert all(hashlib.sha256((P/'workspace'/f).read_bytes()).hexdigest()==h for f,h in protected.items())
(P/'logs/protected-sha256.json').write_text(json.dumps(protected,indent=2),encoding='utf8')
print('Additional repairs and',len(protected),'protected byte hashes checked.')
