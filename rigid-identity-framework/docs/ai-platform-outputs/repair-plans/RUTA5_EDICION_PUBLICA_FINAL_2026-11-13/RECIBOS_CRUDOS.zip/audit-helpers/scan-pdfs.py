from pathlib import Path
import subprocess,re,json,hashlib,os
P=Path(__file__).resolve().parent;I=P/'workspace/rigid-identity-framework';L=P/'logs/pdf-audit';L.mkdir(exist_ok=True)
roots=[('basecore','BASECORE')]+[(f.name,'main') for f in sorted(I.glob('paper*')) if (f/'main.tex').exists()]+[('monolithic','QICN_MONOLITHIC')]
assert len(roots)==13
patterns={
 'local_path':r'(?:[CE]:[\\/]|Users[/\\]irisp|/home/irisp|research/scripts/|docs/ai-platform|QICN-SYSTEM)',
 'draft_banner':r'\b(?:BORRADOR|Working Draft|SCAFFOLD ONLY|NOT FINAL MANUSCRIPT|SIXTH HARDENING PASS)\b',
 'iteration_id':r'(?:Stage3[-~]|BPF[-~]\d|SRT[-~]\d|Cycle\s+[1-9]|near_identity|judge-v3|AUDIT_MASTER)',
 'file_path_extension':r'\b[\w.-]+\.(?:json|cjs|mjs|md)\b',
 'rhetorical_filler':r'not rhetoric;?\s+it is|not merely rhetoric|delve into|game-changing|groundbreaking',
}
rows=[]
for folder,name in roots:
 pdf=I/folder/(name+'.pdf');log=(I/folder/(name+'.log')).read_text(encoding='utf8',errors='replace')
 env=os.environ.copy();env.update(TZ='UTC',LC_ALL='C')
 raw=subprocess.check_output(['pdfinfo','-enc','UTF-8','-isodates',str(pdf)],stderr=subprocess.DEVNULL,env=env)
 (L/(folder+'-pdfinfo.bin')).write_bytes(raw)
 info=raw.decode('utf8');(L/(folder+'-pdfinfo.txt')).write_text(info,encoding='utf8')
 textfile=L/(folder+'.txt');subprocess.run(['pdftotext','-enc','UTF-8','-layout',str(pdf),str(textfile)],check=True,stderr=subprocess.DEVNULL)
 text=textfile.read_text(encoding='utf8');flat=re.sub(r'\s+',' ',text)
 meta={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in info.splitlines() if ':' in line}
 assert meta.get('Author')=='Johnny Andrey Pérez Ramírez' and meta.get('Title'),meta
 bad={k:[m[0] for m in re.finditer(p,flat,re.I)] for k,p in patterns.items()};bad={k:v for k,v in bad.items() if v}
 note_count=len(re.findall('The conception, theoretical direction',flat))
 errors={k:len(re.findall(p,log,re.I)) for k,p in {'fatal':r'^!|Fatal error occurred','undefined':r'(?:Reference|Citation).*undefined|There were undefined references','duplicate':r'multiply.defined','overfull_h':r'Overfull \\hbox','overfull_v':r'Overfull \\vbox'}.items()}
 row={'file':str(pdf.relative_to(I)),'pages':int(meta['Pages']),'metadata':meta,'text_sha256':hashlib.sha256(textfile.read_bytes()).hexdigest(),'pdf_sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'authorial_note_body_count':note_count,'last_note_after_references':flat.rfind('The conception, theoretical direction')>flat.rfind('References'),'scan_hits':bad,'log':errors}
 rows.append(row)
 print(folder,row['pages'],'notes',note_count,'hits',bad,'log',errors,flush=True)
 assert note_count==1 and row['last_note_after_references'] and not bad and not any(errors.values()),row
(P/'logs/pdf-audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
print('All 13 PDFs passed text, metadata and log checks.')
