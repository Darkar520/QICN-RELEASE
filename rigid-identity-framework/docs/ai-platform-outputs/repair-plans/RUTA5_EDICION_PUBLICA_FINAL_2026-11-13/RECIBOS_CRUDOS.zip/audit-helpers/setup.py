from pathlib import Path
import subprocess,shutil,json,hashlib,difflib,re
P=Path(__file__).resolve().parent;C=Path('C:/Users/irisp/OneDrive/Escritorio/qicn-framework-ordenado');W=P/'workspace';B=P/'baseline';L=P/'logs';L.mkdir(exist_ok=True)
assert not W.exists(),'Already preserved; do not overwrite'
files=subprocess.check_output(['git','ls-files','-z'],cwd=C).decode().split('\0')[:-1]
dirty=subprocess.check_output(['git','diff','--name-only'],cwd=C,text=True).splitlines()
hashes={}
for f in files:
 for dest in [W,B]:
  p=dest/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(C/f,p)
 if f in dirty:(B/f).write_bytes(subprocess.check_output(['git','show','HEAD:'+f],cwd=C))
 hashes[f]=hashlib.sha256((C/f).read_bytes()).hexdigest()
D='rigid-identity-framework/docs/ai-platform-outputs/repair-plans/RUTA5_EDICION_PUBLICA_FINAL_2026-11-13'
shutil.copytree(C/D,W/D)
shutil.copytree(C/D,P/'initial-preregistration')
(L/'initial-working-hashes.json').write_text(json.dumps(hashes,indent=2))
(L/'initial.patch').write_text(subprocess.check_output(['git','-c','core.quotepath=false','diff'],cwd=C,text=True,encoding='utf8'),encoding='utf8')
envs=r'theorem|proposition|lemma|corollary|definition|remark|nonthm|nontheorem|example|proof|caveat|assumption|nonclaim|hypothesis|axiom|conjecture'
pat=re.compile(r'\\begin\{('+envs+r')\}(?:\[[^\]]*\])?([\s\S]*?)\\end\{\1\}')
findings=[]
for f in dirty:
 a=(B/f).read_text(encoding='utf-8-sig');b=(W/f).read_text(encoding='utf-8-sig')
 labels=lambda s:re.findall(r'\\(?:label|ref|eqref)\{([^}]+)\}',s)
 aa=list(pat.finditer(a));bb=list(pat.finditer(b))
 row={'file':f,'formal_before':len(aa),'formal_after':len(bb),'labels_refs_equal':labels(a)==labels(b),'formal_differences':[]}
 if len(aa)==len(bb):
  for n,(x,y) in enumerate(zip(aa,bb)):
   if x[0]!=y[0]:row['formal_differences'].append({'index':n,'type':x[1],'before':x[0],'after':y[0]})
 findings.append(row)
(L/'initial-formal-audit.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps([{'file':x['file'],'formal_counts':[x['formal_before'],x['formal_after']],'labels_refs_equal':x['labels_refs_equal'],'changed_formal_blocks':len(x['formal_differences'])} for x in findings],indent=2))
