from pathlib import Path
import subprocess,os,json,time,sys
p=Path(__file__).resolve().parent;root=p/'workspace';inner=root/'rigid-identity-framework'
phase=sys.argv[1];out=p/'logs'/phase;out.mkdir(parents=True,exist_ok=True)
env=os.environ.copy();env['TMP']=env['TEMP']=str(p/'tmp');env['npm_config_cache']=str(p/'npm-cache')
steps=[
 ('root-integrity',root,['node','scripts/verify-canonical-integrity.cjs']),
 ('root-claims',root,['node','scripts/verify-claim-registry.cjs']),
 ('root-release',root,['node','scripts/verify-canonical-release.cjs']),
 ('release',inner,['npm.cmd','run','verify:release']),
 ('corpus',inner,['node','scripts/validate-corpus.js']),
 ('macros',inner,['node','scripts/validate-macros.js']),
 ('math',inner,['python','scripts/verify-math-regressions.py']),
 ('prose',inner,['python','scripts/verify-prose-sync.py']),
 ('chapters',inner,['node','docs/ai-platform-outputs/analysis/AUDITORIA_INTEGRAL_CODEX_2026-11-08/check-monolith.cjs'])]
records=[]
for name,cwd,cmd in steps:
 start=time.monotonic()
 with (out/(name+'.log')).open('w',encoding='utf8') as log:
  r=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':cmd,'cwd':str(cwd),'exit':r.returncode,'seconds':round(time.monotonic()-start,2)})
 (out/'commands.json').write_text(json.dumps(records,indent=2),encoding='utf8')
 print(name,r.returncode,flush=True)
 if r.returncode:
  print((out/(name+'.log')).read_text(errors='replace')[-6000:]);raise SystemExit(r.returncode)
